<?php

function Dwoo_Plugin_loaderTest(Dwoo_Core $dwoo)
{
	return 'Moo';
}
