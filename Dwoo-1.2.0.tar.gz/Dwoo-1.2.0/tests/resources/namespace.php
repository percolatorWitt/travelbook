<?php

namespace Dwoo;

class TestHelper {
    public static $var = 'foo';

    public static function execute($arg) {
        return $arg;
    }
}